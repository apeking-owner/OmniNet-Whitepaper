# OmniNet — Public Whitepaper (Phases 1–15)

This repository contains the public version of the OmniNet whitepaper.  
It includes high-level descriptions of all 15 phases of the OmniNet system.

This version does NOT include:
- Source code  
- Internal architecture  
- Proprietary holographic UI code  
- AR implementation details  
- Mesh protocol details  
- Backend logic  

All proprietary components are privately stored.

Author: Alain Lebel Mercier  
Year: 2025
