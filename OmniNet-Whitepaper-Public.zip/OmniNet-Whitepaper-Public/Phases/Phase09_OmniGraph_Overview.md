# Phase 9 — OmniGraph (Public Overview)

OmniGraph is the knowledge mapping system of OmniNet.

High-level:
- Relationship mapping between identity, data, and context
