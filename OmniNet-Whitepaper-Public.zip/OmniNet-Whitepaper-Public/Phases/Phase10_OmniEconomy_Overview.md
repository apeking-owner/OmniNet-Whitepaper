# Phase 10 — OmniEconomy (Public Overview)

OmniEconomy represents the value system of OmniNet.

High-level concept:
- Identity-bound value layer
- Unified microtransaction model
