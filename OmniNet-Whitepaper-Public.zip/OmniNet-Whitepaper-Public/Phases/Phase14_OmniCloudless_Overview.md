# Phase 14 — OmniCloudless (Public Overview)

OmniCloudless describes OmniNet’s cloudless infrastructure model.

High-level:
- P2P-first design
- Decentralized processing
