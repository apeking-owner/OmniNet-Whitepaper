# Phase 2 — OmniVault (Public Overview)

OmniVault is the encrypted data enclave of OmniNet.

It provides:
- Secure storage
- Encrypted user data containers
- Identity-bound access
