# Phase 1 — OmniID (Public Overview)

OmniID provides the universal identity foundation for OmniNet.

It enables:
- User authentication
- Device identity
- Application identity
- Session-level identity

This is the first layer of the OmniNet system.
