# Phase 12 — OmniNodes (Public Overview)

OmniNodes provide compute and logic execution across the network.

High-level:
- Distributed node network
- Edge computation concepts
