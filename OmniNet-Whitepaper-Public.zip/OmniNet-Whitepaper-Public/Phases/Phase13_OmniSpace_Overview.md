# Phase 13 — OmniSpace (Public Overview)

OmniSpace is the spatial computing layer of OmniNet.

High-level:
- Spatial scenes
- Environmental context
