# Phase 8 — OmniMesh (Public Overview)

OmniMesh is the distributed networking layer.

High-level:
- Device-to-device communication structure
- P2P routing concepts
